package com.example.docs;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class Notas extends AppCompatActivity {

    private EditText etNotas, nomNotas;
    private Button GenerarQR;
    private ImageView qrImagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notas);

        etNotas = findViewById(R.id.etNotas);
        nomNotas = findViewById(R.id.nomNotas);

    }

    public void GuardarNote(View view){

        String nombreNota = nomNotas.getText().toString();
        String contenidoNota = etNotas.getText().toString();

        try{
            File TarjetaSD = Environment.getExternalStorageDirectory();
            OutputStreamWriter crearNota = new OutputStreamWriter(openFileOutput(nombreNota,Activity.MODE_PRIVATE));

            crearNota.write(contenidoNota);
            crearNota.flush();
            crearNota.close();

            Toast.makeText(this,"Guardado correctamente",Toast.LENGTH_SHORT).show();

            etNotas.setText("");
            nomNotas.setText("");

        }
        catch (IOException e){
            Toast.makeText(this,"No se pudo guardar la nota",Toast.LENGTH_SHORT).show();
        }

    }

    public void ConsultarNota(View view){

        String nombreNota = nomNotas.getText().toString();

        try{
            File TarjetaSD = Environment.getExternalStorageDirectory();
            InputStreamReader AbrirNota = new InputStreamReader(openFileInput(nombreNota));

            BufferedReader leerNota = new BufferedReader(AbrirNota);
            String linea = leerNota.readLine();
            String contenidoNota = "";

            while(linea != null){
                contenidoNota = contenidoNota + linea + "\n";
                linea = leerNota.readLine();
            }

            leerNota.close();
            AbrirNota.close();
            etNotas.setText(contenidoNota);

        } catch (IOException e){

            Toast.makeText(this,"No se pudo abrir la nota",Toast.LENGTH_SHORT).show();

        }

    }


    public void BorrarNota(View view){

        String nombreNota = nomNotas.getText().toString();
        String contenidoNota = etNotas.getText().toString();

        //File contenidoNota = Environment.getExternalStorageDirectory();

        nomNotas.setText("");
        etNotas.setText("");

        Toast.makeText(this,"Nota eliminada",Toast.LENGTH_SHORT).show();

    }

    public void EnviarNota(View view){

        Intent Enviar = new Intent(Notas.this, Enviar.class);

        String contenidoNota = etNotas.getText().toString();

        Enviar.putExtra("contenidoNota",contenidoNota);

        startActivity(Enviar);
    }

}