package com.example.practica2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Saludo extends AppCompatActivity {

    private TextView SaludoM;
            Bundle Datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo);

        SaludoM = findViewById(R.id.SaludoM);
        Datos = getIntent().getExtras();


    }

    public void recibir(View view){

        Bundle extras = getIntent().getExtras();
        String d1 = extras.getString("nombre");
        String d2 = extras.getString("apellidopa");
        String d3 = extras.getString("apellidoma");
        String d4 = extras.getString("colonia");
        String d5 = extras.getString("codpos");
        String d6 = extras.getString("calle");
        String d7 = extras.getString("estado");
        String d8 = extras.getString("municipio");

        SaludoM.setText("Hola"+d1+","+d2+","+d3+","+d4+","+d5+","+d6+","+d7+","+d8+"");

    }

    public void salir(View view){
        finish();
    }
}