//MONTSERRAT RESNDIZ MUÑOZ;
//25 DE AGOSTO DEL 2022;
package com.example.practica2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText apellidoPa, apellidoMa, nombre, colonia, cp, calle, estado, municipio;

    private TextView et1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        apellidoPa= findViewById(R.id.apellidoPa);
        apellidoMa= findViewById(R.id.apellidoMa);
        nombre= findViewById(R.id.nombre);
        colonia= findViewById(R.id.colonia);
        cp= findViewById(R.id.cp);
        calle= findViewById(R.id.calle);
        estado= findViewById(R.id.estado);
        municipio= findViewById(R.id.municipio);

        et1= findViewById(R.id.et1);

    }
    /*//PRACTICA 2. UNIDAD 1
    public void Datos (View view){

        String app, apm, n, col, codP, call, est, mun;

        app = apellidoPa.getText().toString();
        apm = apellidoMa.getText().toString();
        n = nombre.getText().toString();
        col = colonia.getText().toString();
        codP = cp.getText().toString();
        call = calle.getText().toString();
        est = estado.getText().toString();
        mun = municipio.getText().toString();

        et1.setText("Hola "+n+" "+app+" "+apm+", vives en "+mun+", "+est+", "+col+", "+codP+", "+call+".");

    }*/

    public void limpiar(View view){
        nombre.setText(""); apellidoPa.setText(""); apellidoMa.setText(""); colonia.setText("");
        cp.setText(""); calle.setText(""); estado.setText(""); municipio.setText("");

        et1.setText("");
    }

   public void Datos(View view){

   //PRACTICA 2. UNIDAD 1

        Intent Saludo = new Intent(MainActivity.this, Saludo.class);

        String app = apellidoPa.getText().toString();
        String apm = apellidoMa.getText().toString();
        String n = nombre.getText().toString();
        String col = colonia.getText().toString();
        String codP = cp.getText().toString();
        String call = calle.getText().toString();
        String est = estado.getText().toString();
        String mun = municipio.getText().toString();

        Saludo.putExtra("nombre", n);
        Saludo.putExtra("apelidopa", app);
        Saludo.putExtra("apellidoma", apm);
        Saludo.putExtra("colonia", col);
        Saludo.putExtra("codpos", codP);
        Saludo.putExtra("calle", call);
        Saludo.putExtra("estado", est);
        Saludo.putExtra("municipio", mun);

        startActivity(Saludo);

    }

}