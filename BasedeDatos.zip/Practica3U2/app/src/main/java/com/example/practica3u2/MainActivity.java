package com.example.practica3u2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2, et3, et4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        et3=findViewById(R.id.et3);
        et4=findViewById(R.id.et4);

    }

    public void alta(View view){

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,"administracion",null,1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        String nControl = et1.getText().toString();
        String nombre = et2.getText().toString();
        String semestre = et3.getText().toString();
        String carrera = et4.getText().toString();

        //Toast.makeText(this,"Numero de control: " +nControl + "nombre: " + nombre +"semestre: " +semestre + "carrera: " + carrera, Toast.LENGTH_SHORT).show();

        ContentValues registro = new ContentValues();

        registro.put("nControl", nControl);
        registro.put("nombre", nombre);
        registro.put("semestre", semestre);
        registro.put("carrera", carrera);

        bd.insert("alumno",null, registro);
        bd.close();
        this.limpia();
        Toast.makeText(this,"Datos del alumno cargados",Toast.LENGTH_SHORT).show();


    }

    public void limpia(){

        et1.setText("");
        et2.setText("");
        et3.setText("");
        et4.setText("");

    }

    public void Limpiar(View view){
        this.limpia();
    }

    public void consultar(View view){

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,"administracion", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        String nControl = et1.getText().toString();

        Cursor fila = bd.rawQuery("select nombre, semestre, carrera from alumno where nControl=" +nControl,null);

        if(fila.moveToFirst()){
            //Toast.makeText(this,"Estoy dentro del primer registro", Toast.LENGTH_SHORT).show();
            et2.setText(fila.getString(0));
            et3.setText(fila.getString(1));
            et4.setText(fila.getString(2));
        }else
            Toast.makeText(this,"No existe ningun usuario con ese Número de Control",Toast.LENGTH_SHORT).show();
        bd.close();

    }

    public void bajas(View view){

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion",null,1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        String nControl = et1.getText().toString();

        int cant = bd.delete("alumno","nControl=" +nControl,null);
        bd.close();

        et1.setText("");
        et2.setText("");
        et3.setText("");
        et4.setText("");

        if(cant == 1){
            Toast.makeText(this, "USUARIO ELIMINADO",Toast.LENGTH_SHORT).show();

        }else{
            Toast.makeText(this,"NO EXISTE EL USUARIO",Toast.LENGTH_SHORT).show();
        }
    }

    public void modificacion(View view){

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "administracion",null,1);
        SQLiteDatabase bd = admin.getWritableDatabase();

        String nControl = et1.getText().toString();
        String nombre = et2.getText().toString();
        String semestre = et3.getText().toString();
        String carrera = et4.getText().toString();

        ContentValues registro = new ContentValues();

        registro.put("nombre", nombre);
        registro.put("semestre", semestre);
        registro.put("carrera", carrera);

        int cant = bd.update("alumno", registro,"nControl=" +nControl,null);
        bd.close();

        if(cant == 1){
            Toast.makeText(this,"DATOS MODIFICADOS CON EXITO", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "NO EXISTE USUARIO",Toast.LENGTH_SHORT).show();
        }
    }

}