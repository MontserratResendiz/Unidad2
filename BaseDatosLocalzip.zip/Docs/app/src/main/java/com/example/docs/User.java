package com.example.docs;

public class User {

    String appName, appPass;

    public String getAppName() {
        return appName;
    }

    public String getAppPass() {
        return appPass;
    }
}
