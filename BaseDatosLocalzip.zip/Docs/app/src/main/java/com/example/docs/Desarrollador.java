package com.example.docs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Desarrollador extends AppCompatActivity {

    private EditText asunDes, etSugerencia;
    private Button enviarSug;

    String correoDes = "l21590049@sjuanrio.tecnm.mx";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desarrollador);

        asunDes = findViewById(R.id.asunDes);
        etSugerencia = findViewById(R.id.etSugerencia);
        enviarSug = findViewById(R.id.enviarSug);


        enviarSug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + correoDes));
                intent.putExtra(Intent.EXTRA_SUBJECT,asunDes.getText().toString());
                intent.putExtra(Intent.EXTRA_TEXT,etSugerencia.getText().toString());
                startActivity(intent);
            }
        });

    }
}

