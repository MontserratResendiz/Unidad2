package com.example.docs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Enviar extends AppCompatActivity {

    private TextView NotaReci, destinatario, asunto;
    Button enviarBoton;
    Bundle datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enviar);

        NotaReci = findViewById(R.id.NotaReci);
        destinatario = findViewById(R.id.destinatario);
        asunto = findViewById(R.id.asunto);
        enviarBoton = findViewById(R.id.enviarBoton);

        datos = getIntent().getExtras();
        NotaReci.setText(datos.getString("contenidoNota"));

        enviarBoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + destinatario.getText().toString()));
                intent.putExtra(Intent.EXTRA_SUBJECT,asunto.getText().toString());
                intent.putExtra(Intent.EXTRA_TEXT,NotaReci.getText().toString());
                startActivity(intent);
            }
        });

    }
}